#include "mbed.h"
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "motordriver.h"

DigitalOut myled1(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);

void secuencia_1_leds();

void mover_horario(Motor *m, DigitalOut* dira, DigitalOut *dirh);
void mover_anti_horario(Motor *m, DigitalOut* dira, DigitalOut *dirh);
void parar_motor(Motor *m, DigitalOut* dira, DigitalOut *dirh);
void modificar_velocidad(Motor *m, DigitalOut* dira, DigitalOut *dirh, float speed);

void test(Motor *m, DigitalOut* dira, DigitalOut *dirh, AnalogIn *a, float ini);

void mantener_distancia(int sensor, 
                        Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h, AnalogIn * a1, float ini1, 
                        Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, AnalogIn * a2, float ini2, 
                        Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h, AnalogIn * a3, float ini3);

void rotar_horario(Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h);

void rotar_anti_horario(Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h);
                    
void parar_motores (Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h);


int main() {
    
    
    Serial pc(USBTX, USBRX);
       
    
    /*
        Control de sensores de distancia
    */
    
    AnalogIn a1(p17);
    AnalogIn a2(p19);
    AnalogIn a3(p20);
    
    /*
        Control de motores
    */
    
    
    DigitalOut motorEN(p24);
    
    DigitalOut dir1a(p30);
    DigitalOut dir2a(p29);
    DigitalOut dir3a(p26);
    
    DigitalOut dir1h(p14);
    DigitalOut dir2h(p15);
    DigitalOut dir3h(p16);
    
    Motor m1(p23, p30, p14, 0);
    Motor m2(p22, p29, p15, 0);
    Motor m3(p21, p26, p16, 0);   
    
    m1.speed(0.0f);
    m2.speed(0.0f);
    m3.speed(0.0f);  
    float ini1 = a1.read();
    float ini2 = a2.read();
    float ini3 = a3.read();

    secuencia_1_leds();
    
    while(1){
        
        
        /*       
        parar_motor(&m1, &dir1a, &dir1h);
        parar_motor(&m2, &dir2a, &dir2h);
        
        wait(5.0f);
        
        mover_horario(&m1, &dir1a, &dir1h);
        mover_horario(&m2, &dir2a, &dir2h);
        mover_horario(&m3, &dir3a, &dir3h);
        
        wait(5.0f);
        
        parar_motor(&m1, &dir1a, &dir1h);
        parar_motor(&m2, &dir2a, &dir2h);
        parar_motor(&m3, &dir3a, &dir3h);
        
        wait(5.0f);
        */
        
        mantener_distancia(3, 
                            &m1, &dir1a, &dir1h, &a1, ini1, 
                            &m2, &dir2a, &dir2h, &a2, ini2, 
                            &m3, &dir3a, &dir3h, &a3, ini3);

    }
        
        // Control de distancia
            // Lectura de sensores
            // Calculo de distancia
                // Linea recta
                // Rotacion
        // Accion de motores
        
        /*
        pc.printf("%f - ", ai17.read());
        pc.printf("%f - ", ai19.read());
        pc.printf("%f\n\r", ai20.read());
        pc.printf("\n\r");
        */
        //pc.printf("%f - ", ai5.read());
        //pc.printf("\n\r");
        
}

void secuencia_1_leds(){
    
    myled1 = 1;
    wait(0.2f);
    myled2 = 1;
    wait(0.2f);
    myled3 = 1;
    wait(0.2f);
    myled4 = 1;
    wait(0.2f);
    
    myled4 = 0;
    wait(0.2f);
    myled3 = 0;
    wait(0.2f);
    myled2 = 0;
    wait(0.2f);
    myled1 = 0;
    wait(0.2f);
    
}

void mover_horario(Motor *m, DigitalOut* dira, DigitalOut *dirh) {
    m->speed(1.0f);
    *dira = 0;
    *dirh = 1; 
}

void mover_anti_horario(Motor *m, DigitalOut* dira, DigitalOut *dirh){
    m->speed(1.0f);
    *dira = 1;
    *dirh = 0;
}

void parar_motor(Motor *m, DigitalOut* dira, DigitalOut *dirh){
    m->speed(0.0f);
    *dira = 0;
    *dirh = 0;
}

void test(Motor *m, DigitalOut* dira, DigitalOut *dirh, AnalogIn *a, float ini){

       if (a->read() < ini){
            m->speed(1.0f);
            *dira = 1;
            *dirh = 0;
        } else {         
            m->speed(1.0f);
            *dira = 0;
            *dirh = 1;   
        }
}

void modificar_velocidad(Motor *m, DigitalOut* dira, DigitalOut *dirh, float speed){
    m->speed(speed);
    *dira = 1;
    *dirh = 0;
}

void mantener_distancia(int sensor, 
                        Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h, AnalogIn * a1, float ini1, 
                        Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, AnalogIn * a2, float ini2, 
                        Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h, AnalogIn * a3, float ini3){
                            
    float margenSup = 0.0f;
    float margenInf = 0.0f;
    float sensorDist = 0.0f;
    float ajuste = 10.0f/100.0f;
    
    if (sensor == 1) {
        sensorDist = a1->read();
        margenSup = ini1 + ini1*ajuste;
        margenInf = ini1 - ini1*ajuste;
        if (sensorDist > margenSup){
            // Esta mas cerca
            mover_horario(m2, dir2a, dir2h);
            mover_anti_horario(m3, dir3a, dir3h);
            
        } else if (sensorDist < margenInf ) {
            // Esta mas lejos
            mover_horario(m3, dir3a, dir3h);
            mover_anti_horario(m2, dir2a, dir2h);      
        }
    } else if (sensor == 2) {
        sensorDist = a2->read();
        margenSup = ini2 + ini2*ajuste;
        margenInf = ini2 - ini2*ajuste;
        if (sensorDist > margenSup){
            // Esta mas cerca
            mover_horario(m3, dir3a, dir3h);
            mover_anti_horario(m1, dir1a, dir1h);
        } else if (sensorDist < margenInf ) {
            // Esta mas lejos
            mover_horario(m1, dir1a, dir1h);
            mover_anti_horario(m3, dir3a, dir3h);      
        }
    } else if (sensor ==3) {
        sensorDist = a3->read();
        margenSup = ini3 + ini3*ajuste;
        margenInf = ini3 - ini3*ajuste;
        if (sensorDist > margenSup){
            // Esta mas cerca
            mover_horario(m1, dir1a, dir1h);
            mover_anti_horario(m2, dir2a, dir2h);
        } else if (sensorDist < margenInf ) {
            // Esta mas lejos
            mover_horario(m2, dir2a, dir2h);
            mover_anti_horario(m1, dir1a, dir1h);    
        }
    }
    
}


void rotar_horario(Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h){
                        
    mover_anti_horario(m1, dir1a, dir1h);
    mover_anti_horario(m2, dir2a, dir2h);
    mover_anti_horario(m3, dir3a, dir3h);
}

void rotar_anti_horario(Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h){
                        
    mover_horario(m1, dir1a, dir1h);
    mover_horario(m2, dir2a, dir2h);
    mover_horario(m3, dir3a, dir3h);
}

void parar_motores (Motor * m1, DigitalOut* dir1a, DigitalOut *dir1h,
                    Motor * m2, DigitalOut* dir2a, DigitalOut *dir2h, 
                    Motor * m3, DigitalOut* dir3a, DigitalOut *dir3h){
    
    parar_motor(m1, dir1a, dir1h);
    parar_motor(m1, dir1a, dir1h);
    parar_motor(m1, dir1a, dir1h);                       
                        
}